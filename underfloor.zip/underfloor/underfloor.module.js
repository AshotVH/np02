'use strict';
angular.module('underfloor', [
    'ngRoute'
]);